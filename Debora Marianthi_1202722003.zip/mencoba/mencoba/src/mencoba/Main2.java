/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mencoba;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;


/**
 *
 * @author Debora Marianthi
 */
public class Main2 {
    
   public static void main(String[] args) {

        //Koneksi ke ObjectDB + Pembuatan database
        EntityManagerFactory emf
                = Persistence.createEntityManagerFactory(
                        "$objectdb/db/CutiKaryawan.odb");
        EntityManager em = emf.createEntityManager();

        //Pembuatan Data
            em.getTransaction().begin();
      
      CutiKaryawan ck1 = new CutiKaryawan("IP06001", "2012-02-01", "3", "Acara Keluar");
      CutiKaryawan ck2 = new CutiKaryawan("IP06001", "2012-02-13", "2", "Anak sakit");
      CutiKaryawan ck3 = new CutiKaryawan("IP07007", "2012-02-15", "1", "Nenek sakit");
      CutiKaryawan ck4 = new CutiKaryawan("IP06003", "2012-02-17", "1", "Mendaftar sekolah anak");
      CutiKaryawan ck5 = new CutiKaryawan("IP07006", "2012-02-20", "5", "Menikah");
      CutiKaryawan ck6 = new CutiKaryawan("IP07004", "2012-02-27", "1", "Imunisasi anak");
      
       em.persist(ck1);
       em.persist(ck2);
       em.persist(ck3);
       em.persist(ck4);
       em.persist(ck5);
       em.persist(ck6);
            
       em.getTransaction().commit();
       
        
        //READ DATABASE MenggunakanRetrieve Data
         TypedQuery<CutiKaryawan> query
      = em.createQuery("SELECT CutiKaryawan FROM CutiKaryawan cutikaryawan",
         CutiKaryawan.class);
      List<CutiKaryawan> results = query.getResultList();
      for (CutiKaryawan data : results) {
         System.out.println(data);
      }

        em.close();
        emf.close();

    }
}

